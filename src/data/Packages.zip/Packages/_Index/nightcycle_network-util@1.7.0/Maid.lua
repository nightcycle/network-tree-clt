local REQUIRED_MODULE = require(script.Parent.Parent["nightcycle_maid@1.1.4"]["maid"])
export type Maid = REQUIRED_MODULE.Maid 
export type MaidConstructor = REQUIRED_MODULE.MaidConstructor 
return REQUIRED_MODULE
