return require(script.Parent._Index["nightcycle_network-util@1.7.0"]["network-util"])
